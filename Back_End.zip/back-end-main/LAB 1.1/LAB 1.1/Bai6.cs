﻿//using System;

//class Program
//{
//    static void Main()
//    {
//        Console.OutputEncoding = System.Text.Encoding.UTF8;

//        double number;
//        Console.Write("Nhập số: "); 
//        while (!double.TryParse(Console.ReadLine(), out number))
//            Console.Write("Nhập sai! Mời nhập lại: ");

//        Console.WriteLine(number > 0 ? $"{number} là số dương" :
//                         number < 0 ? $"{number} là số âm" : "Đây là số 0");
//    }
//}